from urllib.parse import urlencode, parse_qsl, unquote, urlparse
from xbmcplugin import addDirectoryItem, endOfDirectory, setResolvedUrl, setContent
from xbmcaddon import Addon
from xbmc import executebuiltin
from time import sleep
from http.client import HTTPSConnection
from requests import Session
from datetime import datetime, timedelta
import re, sys, requests, xbmcgui
addon_url = sys.argv[0]
HANDLE = int(sys.argv[1])
addon_name = Addon().getAddonInfo('name')
ICON = Addon().getAddonInfo('icon')
UA = 'Mozilla/5.0 (Linux; Android 15; Pixel 9 Pro Build/AP4A.261212) AppleWebKit/605.1.15 (KHTML, like Gecko) Chrome/134.0.0.0 Mobile Safari/605.1.15 EdgA/134.0.0.0'
def addDir(title, logo, mode, is_folder=True, **kwargs):
    dir_url = f'{addon_url}?{urlencode({"mode": mode, **kwargs})}'
    list_item = xbmcgui.ListItem(label=title)
    list_item.setArt({'icon': logo, 'thumb': logo, 'poster': logo, 'fanart': logo})
    info_tag = list_item.getVideoInfoTag()
    info_tag.setTitle(title)
    info_tag.setPlot(title)
    setContent(HANDLE, 'videos')
    if not is_folder:
        list_item.setProperty('IsPlayable', 'true')
    addDirectoryItem(HANDLE, dir_url, list_item, is_folder)
def getlink(url):
    r = requests.get(url, timeout=20, headers={'user-agent': UA, 'referer': url.encode('utf-8')})
    r.encoding = 'utf-8'
    return r
def referer(url):
    parsed_url = urlparse(url.strip())
    return f'{parsed_url.scheme}://{parsed_url.netloc}'
def urlfix(url):
    cleaned_location = '%20'.join(url.strip().split())
    return re.sub(r':(\/+)', r'://', cleaned_location)
def remove_html_tags(text):
    return re.sub(r'<[^>]*>', '', text)
def convert_to_gmt7(time_str):
    time_obj = datetime.strptime(time_str, "%H:%M")
    time_gmt7 = time_obj + timedelta(hours=7)
    return time_gmt7.strftime("%H:%M")
def fu(url):
    parsed_url = urlparse(url)
    conn = HTTPSConnection(parsed_url.netloc)
    conn.request('HEAD', parsed_url.path)
    response = conn.getresponse().getheader('Location')
    if response is not None:
        return urlfix(response)
    else:
        with Session() as s:
            try:
                r = s.get(url, timeout=20, allow_redirects=False)
            except:
                r = s.get(url, timeout=20, verify=False, allow_redirects=False)
        try:
            return urlfix(r.headers['Location'])
        except:
            return urlfix(r.url)
def process_items(items):
    for a in items:
        tentran = a['name']
        idtran = a.get('share', {}).get('url')
        anhtran = a['image']['url']
        if a.get('sources', ''):
            org_metadata = a.get('org_metadata', {}).get('title', '')
            m = re.search(r"(\d{2}:\d{2})", org_metadata)
            thoigian = m.group(1) if m else ''
            blv = a.get('label') and a['label'].get('text', '') or ''
            for b in a['sources']:
                for c in b['contents']:
                    stream = sum(len(d.get('stream_links', [])) for d in c.get('streams') or [])
                    tenf1 = f'{thoigian} {tentran}' if thoigian else tentran
                    tenf = f'{tenf1} | {blv}' if blv else tenf1
                    if stream > 1:
                        addDir(tenf, anhtran, 'detail_thapcam', idtran = idtran, idm = anhtran, idt = tentran)
                    else:
                        for d in c['streams']:
                            for e in d['stream_links']:
                                if e['type'] != 'webview':
                                    if e.get('request_headers'):
                                        addDir(tenf, anhtran, 'play', link = e['url'], ref = e['request_headers'][0]['value'], is_folder=False)
                                    else:
                                        addDir(tenf, anhtran, 'play', link = e['url'], is_folder=False)
def router(paramstring):
    params = dict(parse_qsl(paramstring))
    if not params:
        addDir('NHÀ ĐÀI', ICON, 'index_nhadai')
        addDir('TRẬN CẦU TÂM ĐIỂM', ICON, 'index_vebo')
        data = getlink('https://sport.xoilaczz.link/providers').json()['groups']
        for k in data:
            if re.search(r"'stream_links'\s*:\s*\[\s*{", str(k)):
                addDir(k['name'], ICON, 'list_thapcam', idk = k['remote_data']['url'])
        endOfDirectory(HANDLE)
        sleep(600)
        executebuiltin('Container.Refresh()')
    elif params['mode'] == 'index_nhadai':
        resp = getlink('https://daddylive.sx/schedule/schedule-generated.json').json()
        for schedule in resp.values():
            for show_type, shows in schedule.items():
                tenshow = remove_html_tags(show_type)
                addDir(tenshow, ICON, 'list_nhadai', ids = show_type)
        endOfDirectory(HANDLE)
        sleep(600)
        executebuiltin('Container.Refresh()')
    elif params['mode'] == 'list_nhadai':
        ids = params['ids']
        resp = getlink('https://daddylive.sx/schedule/schedule-generated.json').json()
        for schedule in resp.values():
            for show_type, shows in schedule.items():
                if ids == show_type:
                    for show in shows:
                        event = show.get('event')
                        time = show.get('time')
                        time_gmt7 = convert_to_gmt7(time) if time else ''
                        tentran = f'{time_gmt7} {event}'
                        channels = show.get('channels', [])
                        channel_ids = [ch.get('channel_id', '') for ch in channels if isinstance(channels, list)]
                        if len(channel_ids) > 1:
                            addDir(tentran, ICON, 'detail_nhadai', ev=event)
                        elif channel_ids:
                            channelid = channel_ids[0]
                            addDir(tentran, ICON, 'play_nhadai', link = channelid, is_folder=False)
        endOfDirectory(HANDLE)
        sleep(600)
        executebuiltin('Container.Refresh()')
    elif params['mode'] == 'detail_nhadai':
        ev = params['ev']
        resp = getlink('https://daddylive.sx/schedule/schedule-generated.json').json()
        for schedule in resp.values():
            for show_type, shows in schedule.items():
                for show in shows:
                    event = show.get('event')
                    if ev == event:
                        channels = show.get('channels', [])
                        if isinstance(channels, list):
                            for ch in channels:
                                channelid = ch.get('channel_id', '')
                                channelname = ch.get('channel_name', '')
                                ten = f'{ev} | {channelname}'
                                addDir(ten, ICON, 'play_nhadai', link = channelid, is_folder=False)
        endOfDirectory(HANDLE)
        sleep(600)
        executebuiltin('Container.Refresh()')
    elif params['mode'] == 'index_vebo':
        resp = getlink('https://api.vebo.xyz/api/match/featured/mt').json()['data']
        for k in resp:
            time = datetime.fromtimestamp(int(k['timestamp'])/1000).strftime('%H:%M')
            blv = ' - '.join((h['name'] for h in k['commentators'] or []))
            tenv = f'{time} {k["name"]} | {blv}' if blv else f'{time} {k["name"]}'
            logotour = k['tournament']['logo']
            addDir(tenv, logotour, 'list_vebo', idk = k['id'], tentran = tenv, anhtran = logotour, slug = k['slug'])
        endOfDirectory(HANDLE)
        sleep(600)
        executebuiltin('Container.Refresh()')
    elif params['mode'] == 'list_vebo':
        urlvb = fu('https://vebo.tv')
        slug = params['slug']
        idk = params['idk']
        tenm = params['tentran']
        anhtran = params['anhtran']
        resp = getlink(f'{urlvb}truc-tiep/{slug}-{idk}').text
        ref = referer(re.search(r"base_embed_url.*?'(.*?)'", resp)[1])
        kq = getlink(f'http://api.vebo.xyz/api/match/{idk}/meta').json()['data']['play_urls']
        for k in kq:
            tenv = f"{tenm} | {k['name']}"
            addDir(tenv, anhtran, 'play', link = k['url'], ref = f'{ref}/', is_folder=False)
        endOfDirectory(HANDLE)
        sleep(600)
        executebuiltin('Container.Refresh()')
    elif params['mode'] == 'list_thapcam':
        idp = params['idk']
        data = getlink(idp).json()
        all_data = []
        if 'groups' in data:
            g = data['groups']
            for k in g:
                process_items(k['channels'])
        else:
            process_items(data['channels'])
        endOfDirectory(HANDLE)
        sleep(600)
        executebuiltin('Container.Refresh()')
    elif params['mode'] == 'detail_thapcam':
        idtran = params['idtran']
        anhtran = params['idm']
        tentran = params['idt']
        data = getlink(idtran).json()['channel']['sources']
        for b in data:
            for c in b['contents']:
                for d in c['streams']:
                    blv = d['name']
                    for e in d['stream_links']:
                        if e['type'] != 'webview':
                            tenf = f'{tentran} | {blv} | {e["name"]}'
                            if e.get('request_headers'):
                                addDir(tenf, anhtran, 'play', link = e['url'], ref = e['request_headers'][0]['value'], is_folder=False)
                            else:
                                addDir(tenf, anhtran, 'play', link = e['url'], is_folder=False)
        endOfDirectory(HANDLE)
        sleep(600)
        executebuiltin('Container.Refresh()')
    elif params['mode'] == 'play':
        play_item = xbmcgui.ListItem(offscreen=True)
        hdr = f'verifypeer=false&User-Agent={unquote(UA)}'
        linkplay = re.sub(r'\s+', '%20', params['link'].strip(), flags=re.UNICODE)
        if params.get('ref'):
            ref = params['ref']
            hdr += f'&Referer={ref}/'
        if 'm3u8' in linkplay:
            play_item.setProperty('inputstream', 'inputstream.adaptive')
            play_item.setProperty('inputstream.adaptive.stream_headers', hdr)
            play_item.setProperty('inputstream.adaptive.manifest_headers', hdr)
        else:
            linkplay = f'{linkplay}|{hdr}'
        play_item.setPath(linkplay)
        setResolvedUrl(HANDLE, True, listitem=play_item)
    elif params['mode'] == 'play_nhadai':
        play_item = xbmcgui.ListItem(offscreen=True)
        baseurl = 'https://daddylive.sx/'
        link = f"{baseurl}embed/stream-{params['link']}.php"
        url_1 = re.search('iframe src="([^"]*)', getlink(link).text)[1]
        ref = referer(url_1)
        resp2 = getlink(url_1).text
        stream_id = re.search(r"fetch\('([^']*)", resp2)[1]
        url_2 = re.search(r'var channelKey = "([^"]*)', resp2)[1]
        m3u8 = re.search(r'(\/mono\.m3u8)',resp2)[1]
        key = re.search(r':"([^"]*)', getlink(f'{ref}{stream_id}{url_2}').text)[1]
        play_item.setPath(f'https://{key}.iosplayer.ru/{key}/{url_2}{m3u8}|verifypeer=false&Referer={ref}/&Origin={ref}&User-Agent={unquote(UA)}')
        setResolvedUrl(HANDLE, True, listitem=play_item)
try:
    router(sys.argv[2][1:])
except:
    pass